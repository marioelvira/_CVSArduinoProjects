#ifdef __cplusplus
extern "C" {
#endif

#ifndef _MRAM_H_
#define _MRAM_H_

#include "main.h"

#endif // _MRAM_H_

#ifdef __cplusplus
} // extern "C"
#endif
