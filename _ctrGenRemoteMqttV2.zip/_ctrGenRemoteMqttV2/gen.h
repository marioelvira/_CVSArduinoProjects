#ifdef __cplusplus
extern "C" {
#endif

#ifndef _GEN_H_
#define _GEN_H_

#endif // _GEN_H_

#ifdef __cplusplus
} // extern "C"
#endif
