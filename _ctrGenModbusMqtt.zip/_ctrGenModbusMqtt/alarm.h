#ifdef __cplusplus
extern "C" {
#endif

#ifndef _ALARM_H_
#define _ALARM_H_

#define AL_ARRAY_SIZE    8

#define AL_ERROR_MB1      0
#define AL_ERROR_MB2      1

#endif // _ALARM_H_

#ifdef __cplusplus
} // extern "C"
#endif
