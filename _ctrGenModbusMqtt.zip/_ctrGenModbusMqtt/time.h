#ifdef __cplusplus
extern "C" {
#endif

#ifndef _TIME_H_
#define _TIME_H_

#include "main.h"

#endif // _TIME_H_

#ifdef __cplusplus
} // extern "C"
#endif
