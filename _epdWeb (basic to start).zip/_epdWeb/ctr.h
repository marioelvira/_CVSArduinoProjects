#ifdef __cplusplus
extern "C" {
#endif

#ifndef _CTR_H_
#define _CTR_H_

#define MODE_TEST   1
#define MODE_AUTO   0

// Estados principales...
#define STATE_START         0

#endif // _CTR_H_

#ifdef __cplusplus
} // extern "C"
#endif
