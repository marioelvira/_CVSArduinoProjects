#ifdef __cplusplus
extern "C" {
#endif

#ifndef _ADCS_H_
#define _ADCS_H_

#define ADC_ARRAY_SIZE      5

#endif // _ADCS_H_

#ifdef __cplusplus
} // extern "C"
#endif
