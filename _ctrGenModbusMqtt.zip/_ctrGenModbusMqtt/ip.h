#ifdef __cplusplus
extern "C" {
#endif

#ifndef _IP_H_
#define _IP_H_

#include "main.h"

#define DHCP_MODE    0
#define FIXIP_MODE   1

#endif // _IP_H_

#ifdef __cplusplus
} // extern "C"
#endif
