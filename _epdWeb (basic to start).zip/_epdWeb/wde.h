#ifdef __cplusplus
extern "C" {
#endif

#ifndef _WDE_H_
#define _WDE_H_

#include "main.h"

#define WTE_TIMEOUT   3000

#endif // _WDE_H_

#ifdef __cplusplus
} // extern "C"
#endif
