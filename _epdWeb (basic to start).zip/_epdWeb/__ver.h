#define PROJECT     "EDP CONTROL+"
#define FW_VERSION  "0.0.0"
